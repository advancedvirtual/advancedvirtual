from tqdm import tqdm
import requests, os


#print("downloading file: \"vs_professional__1262872933.1619176056.exe\".....")



if not os.path.exists("vs_professional__1262872933.1619176056.exe"):
    print("Downloading \"vs_professional__1262872933.1619176056.exe\".....")
    url = "https://github.com/ArchiveOfAnything/VMGET/raw/main/DownloadData/Apps/vs_professional__1262872933.1619176056.exe"
    # Streaming, so we can iterate over the response.
    response = requests.get(url, stream=True)
    total_size_in_bytes= int(response.headers.get('content-length', 0))
    block_size = 1024 #1 Kibibyte
    progress_bar = tqdm(total=total_size_in_bytes, unit='iB', unit_scale=True)
    with open('vs_professional__1262872933.1619176056.exe', 'wb') as file:
        for data in response.iter_content(block_size):
            progress_bar.update(len(data))
            file.write(data)
    progress_bar.close()
    if total_size_in_bytes != 0 and progress_bar.n != total_size_in_bytes:
        print("ERROR, something went wrong")
else:
    print("Downloading skipped! File \"vs_professional__1262872933.1619176056.exe\" is already exists.......")    ###vvv###v###v###

requirements = "Microsoft.VisualStudio.Workload.ManagedGame,Component.UnityEngine.x64,Component.UnityEngine.x86"

if input("install .net applications workload? [y/n]: ") == "y":
    requirements += ",Microsoft.VisualStudio.Workload.ManagedDesktop"
if input ("install C++ applications workload? [y/n]: ") == "y":
    requirements += ",Microsoft.VisualStudio.Workload.NativeDesktop"
if input ("install Python applications workload? [y/n]: ") == "y":
    requirements += ",Microsoft.VisualStudio.Workload.Python"
if input ("install UWP applications workflow? [y/n]: ") == "y":
    requirements += ",Microsoft.VisualStudio.Workload.Universal"
if input("install recomendeds ? [y/n]: ") == "y":
    requirements += ",includeRecommended"
if input("install optionals ? [y/n]: ") == "y":
    requirements += ",includeOptional"

requirements = requirements.replace(",", ";")


print("Starting process: \"",f"vs_professional__1262872933.1619176056.exe install -p --lang ru-RU --productId Microsoft.VisualStudio.Product.Professional --channelId VisualStudio.19.Release --add {requirements}", "\".....")
os.system(f"vs_professional__1262872933.1619176056.exe install -p --lang ru-RU --productId Microsoft.VisualStudio.Product.Professional --channelId VisualStudio.19.Release --add {requirements}")